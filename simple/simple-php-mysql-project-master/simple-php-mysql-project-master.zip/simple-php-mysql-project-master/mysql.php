<?php

$resid=MySQLi_Connect('localhost','root','@connectme','shangout');
					if(MySQLi_Connect_Errno()) {
						echo "<tr align='center'> <td colspan='5'> Failed to connect to MySQL </td> </tr>";
					}
					else {
					}

?>
